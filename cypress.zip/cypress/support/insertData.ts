import * as insertData from "../fixtures/data.json"

export function insert() {

    cy.get(insertData.newMessage).click({force:true});
    cy.get(insertData.newMessage).click({force:true});
    cy.get(insertData.recipient).clear().type(Cypress.env('Recipient'));
    cy.get(insertData.title).clear().type(Cypress.env('title'));
    cy.get(insertData.message).clear().type(Cypress.env('message')).type('{enter}');
    cy.get(insertData.send).click();

}